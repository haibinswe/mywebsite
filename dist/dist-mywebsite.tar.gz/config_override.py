# -*- coding: utf-8 -*-

'''
Override configuration
'''

__author__='haibin'

configs = {
    'db':{
        'host': '127.0.0.1'
    }
}