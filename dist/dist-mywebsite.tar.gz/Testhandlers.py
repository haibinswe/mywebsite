import unittest
from handlers import api_create_comment

class MyTestCase(unittest.TestCase):
    pass



if __name__ == '__main__':
    unittest.main()
